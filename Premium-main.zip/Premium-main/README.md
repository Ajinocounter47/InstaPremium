# Instagram Brute Force Premium - From Indonesian
**Premium** is a script created using the Python programming language which has a function to **Hack Instagram** accounts randomly with an easy list of passwords. This script is highly recommended for beginners because there are various ways to use this script.
<p align="left"><img src="Data/Images/Premium.jpg"/></p>

<p align="left">
  <img src="https://img.shields.io/badge/Author-Rozhak-blue?style=flat-square">
  <img src="https://img.shields.io/badge/Open%20Source-No-red?style=flat-square">
  <img src="https://img.shields.io/badge/Maintained%3F-Yes-green?style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Python-yellow?style=flat-square">
</p>

[![GitHub watchers](https://img.shields.io/github/watchers/rozhakxd/Premium.svg?style=social&label=Watch)](https://GitHub.com/rozhakxd/Premium/watchers/)
[![GitHub forks](https://img.shields.io/github/forks/rozhakxd/Premium.svg?style=social&label=Fork)](https://GitHub.com/rozhakxd/Premium/network/)
[![GitHub stars](https://img.shields.io/github/stars/rozhakxd/Premium.svg?style=social&label=Star)](https://GitHub.com/rozhakxd/Premium/stargazers/)

##

### Description
**Premium** was made on *30 July 2021* and then I distributed it to the public in November 2021 with version 9.5 which is available on termux and pydroid3. This script becomes paid in 2022 when someone trades this script without my permission. You can also try the ***Facebook Brute Force*** script that we released to complement our Premium script called [**Facemash**](https://github.com/RozhakXD/Facemash).

![Facebook-Image](https://github.com/RozhakXD/Premium/blob/main/Data/Images/Prem.png)

This script will be updated about every 3 or 7 days to ensure the best results. The method used to log in is automatically scraping every time it sends a request.

##

### Features in Script?

- This tool login using new Instagram account cookies.
- The secure feature for Instagram accounts cracked.
- Mass report target Instagram account feature.
- Multiple crack methods and works well.
- Generates a random user-agent.
- Complete data forms to avoid spam and errors.
- Features to get followers, comments, likes and story views.

### Works In Terminal?
  - [Windows PowerShell](https://www.microsoft.com/store/productId/9N0DX20HK701) / Kali Linux
  - [Termux](https://f-droid.org/repo/com.termux_118.apk)
  - [Pydroid3](https://play.google.com/store/apps/details?id=ru.iiec.pydroid3&hl=id)

##
  
### Installation

- **Linux - [Termux](https://drive.google.com/file/d/16C8RCEC_0GJWXzZt1P5-TmsNvj1sxP_y/view?usp=sharing)**
  ```
  >> apt update -y && apt upgrade -y
  >> pkg install clang binutils git libffi openssl libsodium iproute2
  >> pkg remove python -y
  >> pkg install tur-repo -y
  >> pkg install python3.9 -y
  >> python3.9 -m pip install --upgrade pip
  >> git clone https://github.com/RozhakXD/Premium
  >> cd "Premium"
  >> python3.9 -m pip install -r requirements.txt
  >> python3.9 Prem.py
  ```
  - **Running on Termux**
  
    ```
    >> cd "$HOME/Premium"
    >> python3.9 Prem.py
    ```
- **Terminal - [Pydroid3](https://drive.google.com/file/d/15sHyfN95oZcwidvgejNitrXZYoztrrDP/view?usp=sharing)**
  ```
  >> cd /sdcard/Download
  >> mkdir Premium && cd Premium
  >> pip3 install requests futures
  >> wget https://raw.githubusercontent.com/RozhakXD/Premium/main/__pycache__/Prem.py -O Prem.py
  >> python3 Prem.py
  ```
  - **Running on Pydroid3**
  
    ```
    >> cd /sdcard/Download/Premium
    >> python3 Prem.py
    ```
    
- **[Termux - Pydroid3](https://drive.google.com/file/d/13zA6XoqlOt2snlr2BqGlqFCP2aXUAuEl/view?usp=sharing)**
  ```
  >> cd $HOME/Premium/_pycache_
  >> pkg install tur-repo -y
  >> pkg install python3.9 -y
  >> python3.9 -m pip install requests futures
  >> python3.9 Prem.py
  ```
  - **Running on Termux**
  
    ```
    >> cd $HOME/Premium/_pycache_
    >> python3.9 Prem.py
    ```

### PyNacl Or PyCryptodome Not Installed?

- The problem if the module is not installed is the Termux application which has problems during the installation.
- You don't use Termux from play'store you should use ["Version-117"](https://f-droid.org/repo/com.termux_117.apk) or ["Version-118"](https://f-droid.org/repo/com.termux_118.apk).
- Delete Termux data if the problem cannot be resolved.
- I hope you run **"$ apt update -y && apt upgrade -y"** until everything is installed properly.

##

### Overcoming Spam Dumps?

- Open desktop mode **"https://www.instgaram.com"** then refresh every few minutes.
- Turn on airplane mode before starting Dump username.
- Instagram accounts come with a phone number, email and two-factor authentication.

### Getting Successful Results

- Use good methods like : **Instagram Apps 2019, Tinder Apps 2018, Threads Apps 2023, Account Center.**
- Noted for now only new accounts and small follower accounts are successful.
- Use the automatic setting that is "Not Recommended" or number One.
- Using good user-agents such as : **REALME, OPPO, POCO, XIAOMI, SAMSUNG, INFINIX, ONEPLUS, PIXEL, NEXUS, HUAWEI.**
- Search target on **"https://www.instagram.com/explore/"** make sure it has 1k followers and above.

### No Results?

- The target you entered is not good or the password they used is a combination of special characters.
- You don't play **"Airplane Mode"** it is recommended to turn on at 500 username.
- Wrong password selection. Use the recommended password is **DEFAULT, COMPLETE** or number **04, 05**.

### [Open Checkpoint Results?](https://drive.google.com/file/d/11RAN1jMdRK5mCTv8CdUbbGwKet5gnfGh/view?usp=sharing)

- Only works on accounts that are online and the owner has confirmed **"Yes it's me"!**
- First wait about 1-7 days or 30 days after cracking.
- Run the script then select number One or **"Crack Ulang Hasil Checkpoint".**
- Enter the name of the file you want to crack **"dir Results"** to find out the file name.
- Enter the user-agent selection or use the previously used user-agent.

### Why Can't Use WIFI?

- WiFi causes your IP address to be blocked or spam.
- Not getting a Success or Checkpoint result.
- WiFi causes it to get stuck at the words **"HIDUPKAN MODE PESAWAT 2 DETIK".**

### I Only Got Checkpoints?

- Instagram's security is getting tighter and they update all the time.
- Wrong selection of user-agent and method.
- Your provider may have a problem.
- The target that you entered is not good or has been cracked by someone.

### [Results Cannot Be Logged In?](https://drive.google.com/file/d/10kp-862cR3HOuvWRqGx--ZM-Wg-0IG4d/view?usp=drive_link)

- Do not log in to the browser if the account is the result of the **"Application"** method.
- Login using cracked cookies.
- Login to the latest version of the Instagram clone application.
- Turn on **"Airplane Mode"** before logging in.

### Bug Success Result?

- The number of followers does not match.
  - The problem with Instagram can be said that there is one username on two different accounts.
  - Maybe you get an account continuously.
- The cookie has been logged out.
  - Maybe the account owner has changed the password so the cookies is logged out.

### Account Always Logged Out?

- Use cookies on cracked accounts to make them last longer.
- Use the latest version of the browser so you don't get browser spam.
- Change the password on your Instagram account.
- Use the desktop site to get cookies.
- Before entering cookies in the script, make sure the account is online.

##

### Screenshots

![Results/Ok-16-July-2023.txt](https://github.com/RozhakXD/Premium/blob/main/Data/Images/Ok-16-July-2023.png)

##

### Protection Against Attacker
- Use Strong Password (which contains standard password chars + longest as possible).
- Use 2F Authentication.
- Do not use Passwords associated with Names (for example name123).

##

~~~python
print("Happy Hacking Day !")
~~~
